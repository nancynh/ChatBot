/**
   Written & Coded By: Nancy Hong
   Date: Feb 3, 2017
   For: Girl's Who Code Club (at Central)
   */

import java.util.Scanner;   //this is telling the program to retrieve a "book" (called Scanner) from its "library" so it can use the "information" stored in the "book"

public class ChatbotRunner
{   
    public static void main(String[] args)
    {
        /**You can change the name of the chatbot here. Such as:
             * "Nancy"
             * "TurtlesAreMySpiritAnimal"
             * "Plattdaddy"
             * "Ward Sucks Because He Has Mr. Mime"
         * Be sure to keep the name in quotation marks " "          */
        
        //Instructions printed out to the screen
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.print("DISCLAIMER: NGHI IS NOT (ALWAYS) LIKE THIS - Nancy :)" +
                         "\nWelcome! To get started type in your name. \nExamples: \n\txXKillerKittenzzzXx\n\tI<3Coding!\n\tJane Doe\nYour name: ");
        
        //This code receives user input
        Scanner input = new Scanner(System.in);
        String statement = input.nextLine();
        
        //Introduction of Nghi - the chatbot
        String name1 = statement;
        Chatbot c1 = new Chatbot("Nghi", name1);
        System.out.println("Great! Now it's time to meet your new friend! Or enemy... ?");
        System.out.println("This is " + c1.getName() + ":\n" +
                              "      ___\n" +
                             " ,,  // \\\\\n" +
                            "(_,\\/ \\_/ \\\n" +
                            "  \\ \\_/_\\_/>\n" +
                            "  /_/  /_/\n" +
        "You can chat with " + c1.getName() + ". Start by greeting them!\n\t\t(Psst. If you want to stop talking just say \"Bye\")");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        
        System.out.print(name1 + ":\t");
        statement = input.nextLine();
        
        //This runs the program forever UNTIL the user types in "bye"
        loop: while (!statement.toLowerCase().equals("bye"))                //the "loop:" part is just to name the while loop so I can "break" (stop the loop) down in the else if statement
        {
            //Checks what the user types in. If they type in a greeting, chatbot responds with a greeting. If they type in something else, the chatbot responds (somewhat) accordingly
            if(statement.toLowerCase().equals("hi") || statement.toLowerCase().equals("hey") || statement.toLowerCase().equals("hello") || 
              statement.toLowerCase().equals("good day m'lady") || statement.toLowerCase().equals("bonjour") || statement.toLowerCase().equals("hola"))
            {
                System.out.println(c1.getName() + ":\t" + c1.greeting(statement));
            }
            else if(statement.toLowerCase().equals("you're an uncultured swine who doesn't have any birthing hips and can't swim because you're a tortoise and everyone knows turtles are way better"))
            {
                System.out.println(c1.getName() + ":\t...\n\t.....\n\t.........\n\tGOODBYE");
                break loop;
            }
            else
            {
                System.out.println(c1.getName() + ":\t" + c1.respond(statement));
            }
            //The \ is called an escape sequence. With the t (thus making \t ) it tells the program to "tab" the words over once
            //With an "n" however (like \n) then it would make the words printed on screen go onto a new line
            System.out.print(name1 + ":\t");
            statement = input.nextLine();
        }
    }
}
