/**
Written & Coded By: Nancy Hong
Date: Feb 5, 2017
For: Girl's Who Code Club (at Central)
 */

import java.util.Random;    //Same thing as the java.util.Scanner in the ChatbotRunner class except this time, the program is getting info from a book called "Random"
import java.util.Scanner;   //this is telling the program to retrieve a "book" (called Scanner) from its "library" so it can use the "information" stored in the "book"
public class Chatbot
{
    Scanner input = new Scanner(System.in);
    String r;   //Response statement
    private String name; //name of the chatbot
    private String nameP; //name of the player
    private Random rand = new Random();  //random number thing
    private int x; //        x = rand.nextInt(3) + 0; is some sample code. 2 would be the max. "+ 0" would mean 0 is the mean but unnecssary to write

    //Constructor. Basically assigns the passed in variables (n which is a String type) into the instance data (in this case, name) 
    public Chatbot(String n, String p)
    {
        name = n;
        nameP = p;
    }

    //Getter method. Methods are the yellow blocks you see. 
    //Because name is private, it cannot be accesed by other classes (with some exceptions). So we need to write a getter method to allow other classes to "get" the name
    String getName() { return name; }

    //Below are all of the methods used to help make the chatbot more... lively? 
    String greeting(String s)
    {     
        if(search(s, "hi"))
        {
            return "Hi! ( ´ ▽ ` )ﾉ";
        }
        else if(search(s, "hey"))
        {
            return "Hey! ╰(｡･ω･｡)";
        }
        else if(search(s, "hello"))
        {
            return "Hello! （*・Ｕ・）ノ☆";
        }
        else if(search(s, "bonjour"))
        {
            return "Bonjour! ✲ﾟ｡.(✿╹◡╹)ﾉ☆.｡₀:*ﾟ✲ﾟ*:₀｡"; 
        }
        else if(search(s, "hola"))
        {
            return "Hola! └╏ ･ ᗜ ･ ╏┐";
        }
        else
        {
            return "...um hi? “Σ⊂(☉ω☉∩ )";
        }
    }

    String respond(String s)
    {
        if(search(s, "tortoise") || search(s, "powers") || search(s, "type") || (search(s, "turtle")))
        {
            return turtle(s);
        }
        else if(search(s, ";)") || search(s, "<3") || search(s, "love you") || search(s, "love u")|| search(s, "cute") || search(s, "love me"))
        {
            return flirt(s);
        }
        else if((search(s, "fav") || search(s, "favorite")) && search(s, "least"))
        {
            return notFav(s);
        }
        else if(search(s, "fav") || search(s, "favorite"))
        {
            return fav(s);
        }
        else if(search(s, "pokemon"))
        {
            return pokemon(s);
        }
        else if(search(s, "how are you") || search(s, "what's up") || search(s, "what's going on") || search(s, "why")) 
        {
            return basics(s);
        }
        else if(search(s, "nancy"))
        {
            return nancy(s);
        }
        else if(search(s, "i hate you") || search(s, "i hate u") || search(s, "fuck off") || search(s, "fuck you") || search(s, "fuck u") || search(s, "shut up"))
        {
            return insults(s);
        }
        else if(((search(s, "tell me a") && (search(s, "joke") || search(s, "story"))) || search(s, "story time") || search(s, "storytime") ||
                (search(s, "not") && search(s, "funny")) || search(s, "that's bad") || search(s, "thats bad")) 
                || s.toLowerCase().equals("sing") || (search(s, "sing") && search(s, "a song")))
        {
            return joke(s);
        }
        else if((search(s, "like") || search(s, "prefer")) && search(s, "or"))
        {
            return "Both. ";
        }
        else if(search(s, "what came first the tortoise or the egg"))
        {
            return "The egg";
        }
        else if(s.equals("..."))   //the ole staring/quiet contest
        {
            String add = "";
            x = rand.nextInt(100);
            for(int i = 1; i < (x / 10); i++)
            {
                add = add + "...";
            }
            if(x == 100)
            {
                add = add + "\n\t*stares*";
            }
            else if(x == 69)
            {
                add = add + "\n\t*blinks*";
            }
            else if(x == 42)
            {
                add = add + "\n\t*farts*\n\tε=(⊃-.-)⊃...\n\t(≧_≦\")\n\tteehee";
            }
            System.out.println(name + ":\t" + s + add);
            System.out.print(nameP + ":\t");
            r = input.nextLine();
            if(r.equals(s + add))
            {
                System.out.println(name + ":\t" + s + add);
                loop2: while(true)
                {
                    System.out.print(nameP + ":\t");
                    r = input.nextLine();
                    if(!r.equals("..."))
                    {
                        return "You lose the game";
                    }
                    else
                    {
                        x = rand.nextInt(100);
                        for(int i = 1; i < (x / 10); i++)
                        {
                            add = add + "...";
                        }
                        
                        if(x == 100)
                        {
                            add = add + "\n\t*stares*";
                        }
                        else if(x == 69)
                        {
                            return "*blinks*\n\tI lost (╥_╥)";
                        }
                        else if(x == 42)
                        {
                            return "*farts*\n\tε=(⊃-.-)⊃...\n\t(≧_≦\")\n\tteehee\n\tI lost because I farted";
                        }
                    }
                    System.out.println(name + ":\t" + s + add);
                }
            }
            else
            {
                return "(._.)";
            }
        }
        else
        {
            x = rand.nextInt(8);
            if(x == 0)
            {
                return "Cool story bro";
            }
            else if(x == 1)
            {
                return "(∪｡∪)｡｡｡zzz\n\tWut... did you say something?";
            }
            else if(x == 2)
            {
                return "That's nice";
            }
            else if(x == 3)
            {
                return "Lol";
            }
            else if(x == 4)
            {
                return "XD";
            }
            else if(x == 5)
            {
                return "Okie";
            }
            else if(x == 6)
            {
                return "...";
            }
            else
            {
                return "I'm a tortoise and I have magical powers.";
            }
        }
    }

    String turtle(String s)
    {
        if(search(s, "power"))
        {
            x = rand.nextInt(4);
            if(x == 0)
            {
                return "My powers are: \n\tBeing able to crush turtles with my sheer weight\n\tSwim on land\n\tWaddling"
                + "\n\tBeing \"smarter\" than a turtle\n\tBeing slippery\n\tAnd having magical farts\n\t\tε＝┏(･ω･)┛ teehee";
            }
            else if(x == 1)
            {
                return "You know, like nunchuck skills, bow hunting skills, computer hacking skills...";    //totally not a reference ;)
            }
            else if(x == 2)
            {
                return "I can kill you with my magical farts that smell like mashed potatoes! (^・x・^)";
            }
            else
            {
                return "I'm more magical than a unicorn ✧٩(ˊωˋ*)و✧";
            }
        }
        else if(search(s, "type"))
        {
            x = rand.nextInt(3);
            if(x == 0)
            {
                return "I'm not an asian snapping turtle";
            }
            else if(x == 1)
            {
                return "I'm a Cambodian tortoise... I mean Filipino... no Thai... uh... Vietnamese! (^-^')";
            }
            else
            {
                return "I'm the type of tortoise to be stupidly cute at all times";
            }
        }
        else if(search(s, "turtle") && ((search(s, "you") && search(s, "are")) || search(s, "you're") || search(s, "youre")))
        {
            x = rand.nextInt(6);
            if(x == 0)
            {
                return "WTF DUDE??? I'M A TORTOISE NOT A TURTLE";
            }
            else if(x == 1)
            {
                return "THERE'S A DIFFERENCE BETWEEN A TORTOISE AND A TURTLE. FOR ONE, TORTOISES ARE WAY CUTER AND SMARTER";
            }
            else if(x == 2)
            {
                return "This is a turtle: ,=,e" +
                "\n\tAnd this is a tortoise: .=.e" +
                "\n\tCan you not tell the difference between the two?!?!";
            }
            else if(x == 3)
            {
                return "Turtle? TURTLE?!?!\n\t┌∩┐(｀益´)┌∩┐";
            }
            else if(x == 4)
            {
                return "You will feel my wrath for calling me a turtle (╬⓪益⓪)";
            }
            else
            {
                return "I'm a tortoise. How insulting.";
            }
        }
        else
        {
            x = rand.nextInt(4);
            if(x == 0)
            {
                return "Congradulations! You just signed up for daily tortoise facts! The fact of the day is:" + 
                "\n\tTortoises are scientifically proven to be better than turtles";
            }
            else if(x == 1)
            {
                return "If you ever see a turtle named Nancy... don't talk to her because she's a turtle and turtles are gross and have cooties";
            }
            else if(x == 2)
            {
                return "Life Pro Tip #42: Tortoises will always win in a fight against turtles";
            }
            else
            {
                return "Tortoises are the best, aren't they? (^(エ)^) ";
            }
        }
    }

    String pokemon(String s)
    {
        x = rand.nextInt(600);
        if(x >= 0 && x < 99)
        {
            return "Ugh. I need to catch more Pokemon ｡･ﾟﾟ･(>д<)･ﾟﾟ･｡";
        }
        else if(x >= 100 && x < 199)
        {
            return "I'm so jealous of Ward because he has Mr. Mime and Nancy has a Snorlax ((ヾ(≧皿≦；)ノ＿))";
        }
        else if(x >= 200 && x < 299)
        {
            return "I'm going to catch them all one day! ٩(｡•ω•｡)و";
        }
        else if(x >= 300 && x < 399)
        {
            return "i suk at pogo";
        }
        else if(x >= 400 && x < 499)
        {
            return "I MISSED ANOTHER RARE POKEMON. AHHHHHH!!!!!!!!!!!!\n\t(ノ｀益´)ノ彡┻━┻";
        }
         if(x == 600)
        {
            return "MUAHAHA! LOOK AT WHAT I CAUGHT!\n\t" +                                                                                                                                                                                             
            "                             `.-:`                                                          \n\t" +
            "                        ``.`-:///.`..-.`                                              \n\t" +
            "                     `...-::////+///++/::`                                              \n\t" +
            "            ````````..--://////++ooooooo+.``                                              \n\t" +
            "            .```.------::////+++++oooosoo///`.--   `.``                                     \n\t" +
            "           `````.---::://///////++o++ossoo++:::/:::/-.`                                     \n\t" +
            "         ``````.:::::::////////+++++soo+:::::://:///:---`                                   \n\t" +
            "          `````./:::::://////////+oo/:---::::://::::-:--`                                   \n\t" +
            "          `.```.+/:::://///////+oo/:.-----:::::/:-..`                                       \n\t" +
            "          `.````+///:////////+os/-..--.--:::///:.`                                          \n\t" +
            "         ``-.``/+/::///:///oo+:...-.--://+oo+//:.                                          \n\t" +
            "          .od+-`-/+:///://+oo:....-:oydddhysoooo:-`                                         \n\t" +
            "          :hmo+o`:///////+o+...-oys/+dNNNNNNhsoo//-                                         \n\t" +
            "         `/dhosNs+/o////+//-/oymNNh``yNNNNNNNmdh+/:`                                        \n\t" +
            "         `/hmyhNyhs:/:////omd+oNmNh-.yNNNNmmNNNNh+:-                                        \n\t" +
            "         ./hsssyyo/--:::--/yhhhdhddyydmNNNNNNNmNdo/:                                        \n\t" +
            "         .-......--://::////--------::/+syhdNNNNs+/-                                        \n\t" +
            "         `.```...-::////++oo/:-..........-:oNNmh+o/`                                        \n\t" +
            "          `.`...-////+++ooosso/-..--..---.:yNmhoso/.                                        \n\t" +
            "          `.`..-:/++++osssyyhso/---------:omdysoo+/:                                        \n\t" +
            "          ````.-:/+osyyhhhhhys+/::-------+shooooso/.``...````                               \n\t" +
            "         ``.....--:/oossssoo/::::::-----+osoosooyo:...........``                            \n\t" +
            "      `.`.-:-......--:::::::------------ossoosssyo/.----------..``                          \n\t" +
            "     ```.-::.........-------------------osysssssyo+--------:-----..`                        \n\t" +
            "    ``..//:-```.........----------------::/osssyyo/-::::--:::::::::-.`                      \n\t" +
            "    ..-:/:-``````...........-----------:--:::::/+//-:::::::::///:::::-.`                    \n\t" +
            "  `..-:::-.``````.............-------------:::::://:/:::::::////////:::-.`                  \n\t" +
            " ``.--:/-.`.````...............------------:::::////:::::://///////////::.`                 \n\t" +
            " `..-://.``.``.................-----------:::::///////::://///++++/////:::-`                \n\t" +
            " ...://+```.``..................---------:::::://////////////+++++++++///::-                \n\t" +
            "``.-////``..`..`...............----------::::://///++///////+++++++++++++//:-`              \n\t" +
            "-..-///:``.``..`...............----------::::://///+++//////++++++++++++++//:.`             \n\t" +
            "-.-:/++:`..`...................-------::::::://////+++++///+++++++++++++++++::-             \n\t" +
            "-.-:/++/``...............-----------:::::::://////+++oo+///+++++++++++oo++++//:-            \n\t" +
            "---/++++``............------------::::::://////+++++oooo++++++++++++oooo++++:/:-`           \n\t" +
            "`.-/++oo.............------------:::::://///++++++++oooo++++++++++ooooooooos+o/`.`          \n\t" +
            " .-:++oo/-......--------------::::::///////++++++++++oooo++++++++ooooooooooyys/.``          \n\t" +
            " .--++ooo:....---------:::::::::::////////+++++++oo++oooo+++++++++oooooooooso:.``.`         \n\t" +
            "  `-//+oo+/....-----:::::::::::://////////+++++++ooooooo++++++oooooooooosoos+-..```         \n\t" +
            "   `-/+ooso+....----::::///:::://///+/////+++++++oooo++++++/++ooooooooooooos+:.`````        \n\t" +
            "    `.:+ooo+:..-----:::://::/:://///+//////+++ooooo+++++++//:/+oooooooooooss/-.````.        \n\t" +
            "      `....:-...----::::///:/:://///+//+///+++oo+++++++++/::.-/+oooooosssso/..``.``.        \n\t" +
            "         ```..``..-----:///:////////+++++/+++++++++++++//:--...-+syyyyyy+/:.```..```        \n\t" +
            "                ``...-:::////////////+////+++++++++++///:--.....--:/oo+:--..`..```          \n\t" +
            "                   `....::::://////////+++++++++////:::--......--...----..--...``           \n\t" +
            "                     ``.``..---::::://///////////:::---.........```  `..`.-: ``.```         \n\t" +
            "                        ..``....-------::::::-------.------..`            ``   `...-`       \n\t" +
            "                          ````......----..------------------`                     `..`      \n\t" +
            "                               ``-/+oo++````````````/++o++/-                                \n\t" +
            "                                `:+ssso/           `/+osoo/                                 \n\t" +
            "                               `-/ososo/           `+ooss+-                                 \n\t" +
            "                         ``..--:/++sosoo.....``.` `./oooo/-                                 \n\t" +
            "             `.-----:----:::+////+oosssy++/:///+/:://oos++:`                                \n\t" +
            "           ``.:+///////++++++++oossossssyss+ooo+////oso+//::                                \n\t" +
            "         ```..:ooo++---/ssoosssssso+/::/++///+//:/+ooo+/-----`                              \n\t" +
            "         ..`..-/::::.-:/yso++++/:-.`      `-:/oso//oo++/-//:/.                              \n\t" +
            "                   `.`.....````           `-`.:oo/:-....-..`/.                              \n\t" +
            "                                           `..---`      .``..`                              \n\t" +
            "                                            ```            `                                ";                                                                      
        }
        else if(x == 599)
        {
            return "WTF kind of pokemon is this? It looks stupid. Transferring this pokemon now...\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMd/--/omMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN/`  .mMMMMMMMMMmodMMMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMs-.` :NMMMMMMMMy``/NMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy--`  +/+oydNNo`  `mMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh+--.  `-   ``-`.  -NMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN+----`   `       `-`/MMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN/----.             `-sMMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN+----.`              `oMMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh----.`   `-.`    `    `+NMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh----.    `./:.`  -`    `/NMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMs---.`    .sy+-` `-`    `+MMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMho:--/odMMMMMMMMMMMMMd+---.`  -ss+-:.``-  ``:dMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMN+`      `sMMMMMMMMMMMNh+::--..` `.:./--:- `/hNMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMh````     `mMMMMMMMMMm:`.-+o---..`  `..``  sNMMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMd.....```.:NMMMMMMMMM/ .:yNMs:--:-.```     oMMMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy:------:/sdmmmNNMMN:-..-:+s+/--/y+//-`..-hMMMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMNmmmNMNh+::::--`---.--odm:...`` `-/-.-mmhsyhhmNMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMd+-...:omh:------.`-:....--.-.`.-.` `.--::``.:ymMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMy`       -/-------::-.`   `-.    `/.`   `..    `.oNMMMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMM/````````./-------/---.`    :.....::`       `   --yMMMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMNNmmmmNNMMMMMMMy---.....:/--/:---/----.````+::::--/.`      :`  --.dMMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMmyo//::::/+oymMMMMMh+:--::osoyhmNmy+/+:-----:yo/-------.``````.:```-.-dMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMNs/:::::::::::::ohNMMMMNmdmNMMMMMMMMMMNNmhysyhNMN+/:-----/-:::---+--.-: .+mMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "Mm+:::://++/::::::::/yNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMdd+----------::-::+/-```.+hNMMMMMMMMMMMMMMMMMMMM\n\t" +
            "N+::/ooydmmdhs+:::::::/hNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy:-----.```````/mh+:.```-+hmNMMMMMMMMMMMMMMMM\n\t" +
            "h::/oohMMMMMMMmy+:::::::omMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMd/----`       .NMMNhs:.`` .-+NMMMMMMMMMMMMMM\n\t" +
            "s::ooyNMMMMMMMMMds+::::::/hMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo---`        oMMMMMMdo:.`` :mMMMMMMMMMMMMM\n\t" +
            "+::oohMMMMMMMMMMMNy+:::::::yNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN:--.        `dMMMMMMMN+-.` .yMMMMMMMMMMMM\n\t" +
            "s::oodMMMMMMMMMMMMNy+:::::::oNMMMMMMMMMMMMMMMMMMMMMMMMMMMMN:---`        -mMMMMMMMNy:-` `+NMMMMMMMMMM\n\t" +
            "y::/ohMMMMMMMMMMMMMNy+:::::::+dMMMMMMMMMMMMMMMMMMMMMMMMMMNo----`       ``:NMMMMMMMMNo-.  -hMMMMMMMMM\n\t" +
            "m:::oyMMMMMMMMMMMMMMmso::::::::yNMMMMMMMMMMMMMMMMMMMMNds/:....-.     `::::++hMMMMMMMMm/`  `+NMMMMMMM\n\t" +
            "N/:::omMMMMMMMMMMMMMMhoo::::::::+mMMMMMMMMMMMMMMMMMm+.         .-   `+:::::/--yNMMMMMMMy`   .sMMMMMM\n\t" +
            "My::::yMMMMMMMMMMMMMMNyoo:::::::::sNMMMMMMMMMMMMMm/`            .- `+:::::::/- -hMMMMMMN:     -yMMMM\n\t" +
            "MN/::::hMMMMMMMMMMMMMMNsoo:::::::::/yNMMMMMMMMMMs`               -`::::::::::/-  /NMMMN:       `:dMM\n\t" +
            "MMd:::::hMMMMMMMMMMMMMMmsoo/::::::::::+ymNMMMMm:                 `:+::::::::::/`  -mMMs`        ..yN\n\t" +
            "MMMs:::::yMMMMMMMMMMMMMMdooo/:::::::::::::/+os.                   /::::::::::::/   :NMy-..+y+.` `+:o\n\t" +
            "MMMNo:::::omMMMMMMMMMMMMMdooo+::::::::::::::/.                    -::::::::::::/    oM+::::dy:-..som\n\t" +
            "MMMMNo::::::+hNMMMMMMMMMMMhoooo+/:::::::::::-                     -::::::/++++:/    .Ndo//s+-:::yMMM\n\t" +
            "MMMMMNs:::::::/ymMMMMMMMMMMhoooooo//:::::::/                      ::::/+ooooooo+     dMMNMMh/::+mMMM\n\t" +
            "MMMMMMNy/::::::::ohNMMMMMMMMdoooooooo+//::::                     `+/+ooooooooos:     dMMMMMMMNNMMMMM\n\t" +
            "MMMMMMMNy+/::::::::/ohNMMMMMMdsooooooooooos`                   ``-sooooooooooo+.    `NMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMNho+::::::::::/ymMMMMMNyooooooooooo                  ``.-ooooooooooos+-.    +MMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMdso+/:::::::::/yNMMMMMmsoooooooo+                ``.-:oooooooooooo/--`   .mMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMmyoo+/:::::::::+dMMMMMNdyoooooo+            ```..-:+ooooooooooo+:--.`  .hMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMNhsooo/:::::::::yMMMMMMMmhsooo+         ``...---+oooooooooso+:----```-dMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMmyoooo+/:::::::dMMMMMMMMNdyso`    ```..-----/ooooooooso+:-------.-oNMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMdyooooo+/::::oMMMMMMMMMMMNo..``...------/oooossyydmh----------+dMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMdyoooooo+::oMMMMMMMMMMMMo-----------:ydddmmNNMMMMN---------yNMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMmhsssosoomMMMMMMMMMMMMo....------omMMMMMMMMMMMMN:------:hMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMNmmmNMMMMMMMMMMMMMM/`  `-----yMMMMMMMMMMMMMMN:------hMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN.   `.--:dMMMMMMMMMMMMMMMy-----.+MMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMo`    `-:mMMMMMMMMMMMMMMNs-----.`oMMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy`     `-hMMMMMMMMMMMMMMy/::-:-`  -NMMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy.     ``:mMMMMMMMMMMMMMN+:-` `.-   :mMMMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy`     `-../NMMMMMMMMMMMMMd:-.```:`   -hNMMMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMs`      -``.-mMMMMMMMMMMMMMMdo:--::.``  `:hNMMMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN+`       :`.-oNMMMMMMMMMMMMMMMMNdo----.``  `:yNMMMMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMd-         ./+yNMMMMMMMMMMMMMMMMMMMMmo:---.``   .+hmNNNNNNNMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMm+`          .sMMMMMMMMMMMMMMMMMMMMMMMMMmo----.`     `.--...-sMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMNd+.    `.     `-sMMMMMMMMMMMMMMMMMMMMMMMMMMMm+---.`     `.....``sMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMNd+.`    ``/`     .-/NMMMMMMMMMMMMMMMMMMMMMMMMMMMMh/--.``    ``  `-.:NMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMN/`      `--.     `---yMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNs---.````     `yNMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMN/```````./      ``---hMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMdo/::::------oNMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMm:-------:-...`..---oNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNNMMMMMMMMMMMMMM\n\t" +
            "MMMMMMMMMMMMMMMMMMMMMMMMMMMMdhssoooods+/:::/odMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM";
        }
        else
        {
            return "Another pidgey!!! My favorite! \n\t ＼＼\\ ٩(๑❛ワ❛๑)و //／／";
        }
    }

    String flirt(String s)
    {
        x = rand.nextInt(6);
        if(x == 0)
        {
            return "U is so cute boo (✿ ♥‿♥)";
        }
        else if(x == 1)
        {
            return "Awww thank you! （*’∀’人）♥";
        }
        else if(x == 2)
        {
            return "You're too kind! （〃・ω・〃）";
        }
        else if(x == 3)
        {
            return "Teehee. Stop. You're making me blush. (/∇＼*)｡o○♡";
        }
        else if(x == 4)
        {
            return "I know you love me ლ(´◉❥◉｀ლ)";
        }
        else
        {
            return "I love you too \n\t(✿ ॣ•͈ᴗ•͈ ॣ)∟ᵒᵛᵉ ∪\tℒσνє♥(๑´ლ`๑)♡ \t ⓛⓞⓥⓔ♡";
        }
    }

    String notFav(String s)
    {
        if(search(s, "book"))
        {
            return "My least favorite book is Harry Pothead... yes Pothead and not Potter because he's a Pothead";
        }
        else if(search(s, "movie"))
        {
            return "All horror movies ヽ(ﾟДﾟ)ﾉ";
        }
        else if(search(s, "class") || search(s, "subject"))
        {
            return "AP Computer Science because it's at Centennial. Gross.";
        }
        else if(search(s, "friend"))
        {
            return "Nancy (duh) because she is a turtle Σ(-᷅_-᷄๑)";
        }
        else if(search(s, "food"))
        {
            return "Chocolate. I'm allegric to it. If you give me any I will die ヘ（゜◇、゜）ノ";
        }
        else if(search(s, "animal"))
        {
            return "I hate turtles. Isn't that a given? (・_・ヾ";
        }
        else if(search(s, "teacher"))
        {
            return "Uh... Σ(‘◉-◉’) Ward. Because he has Mr. Mime and I don't (´;^;`)";
        }
        else if(search(s, "number"))
        {
            return "89 Because I hate having my grade this much or lower in any class \n\t(´･(´･(´･(´･(´･(´･д･`) ･`)･`)･`)･`)･`)";
        }
        else if(search(s, "pokemon"))
        {
            return "Dragonites. They seriously need to spawn less. There's too many of them even after Niantic lowered their spawn rate." + 
            "\n\tMe trying to catch my fav pokemon:\n\tC= C= C= C= C= C= ┌(;･_･)┘ ））● <-Pidgey";
        }
        else if(search(s, "color"))
        {
            return "Black. The color of my soul (-_\\\\\\)";
        }
        else
        {
            return "I hate you... fight me (ง •̀_•́)ง";
        }
    }

    String fav(String s)
    {
        if(search(s, "book"))
        {
            return "My favorite book is 50 Shades of Grey. I love the tension between Anastasia and Christian o｡ﾟ✧(≧ω≦)✧ﾟ｡o";
        }
        else if(search(s, "movie"))
        {
            return "I've gotta say... any Disney movie with a hot British guy in it is my fav! (*๓´╰╯`๓)";
        }
        else if(search(s, "class") || search(s, "subject"))
        {
            return "PE... because we can play Pokemon Go during it. ";
        }
        else if(search(s, "friend"))
        {
            return "Nancy (duh) even if she is a turtle ◟ʕ´∀`ʔ◞◟ʕ´∀`ʔ ◞";
        }
        else if(search(s, "food"))
        {
            return "That's not fair... I love all food. I especially love mashed potatoes though ʕっ˘ڡ˘ςʔ";
        }
        else if(search(s, "animal"))
        {
            return "I love pugs even though I'm a tortoise (^・x・^)";
        }
        else if(search(s, "teacher"))
        {
            return "Ward because he supervises us <(￣︶￣)>";
        }
        else if(search(s, "number"))
        {
            return "π because it reminds me of pies... and I like pies (っ˘ڡ˘)っ─∈ π";
        }
        else if(search(s, "pokemon"))
        {
            return "I can't decide between pidgeys and rattatas... I would have to say pidgeys though because they're so rare (✿´ u ` )";
        }
        else if(search(s, "color"))
        {
            return  "Brown. Just like the color of my poop ¡¡¡( •̀ ᴗ •́ )و!!!\n\t" +
                    "░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\n\t" + 
                    "░░░░░░░░░░░░░░░▓████████▓░░░░░░░░░░░░░░░░\n\t" + 
                    "░░░░░░░░░░░░░░▒█████████▓▒░░░░░░░░░░░░░░░\n\t" + 
                    "░░░░░░░░░░░░░░░▓██▓▓▓▓▓▓███░░░░░░░░░░░░░░\n\t" + 
                    "░░░░░░░░░░░░░░░▓██▓▓▓▓▓▓▓██▓░░░░░░░░░░░░░\n\t" + 
                    "░░░░░░░░░░░░░░░░▓█▓▓▓▓▓▓▓▓█▓░░░░░░░░░░░░░\n\t" + 
                    "░░░░░░░░░░░░░░░░▓█▓▓▓▓▓▓▓▓█▓▒░░░░░░░░░░░░\n\t" + 
                    "░░░░░░░░░░░░░░░▓██▓▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░░░\n\t" + 
                    "░░░░░░░░░░░▒▓▓█████▓▓▓▓▓▓▓▓██▓░░░░░░░░░░░\n\t" + 
                    "░░░░░░░░░▓█████████▓▓▓▓▓▓▓▓███▓▒░░░░░░░░░\n\t" + 
                    "░░░░░░░░▓███▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓████▓░░░░░░░░\n\t" + 
                    "░░░░░░▒████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███▓░░░░░░░\n\t" + 
                    "░░░░░░▓██▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██▓░░░░░░\n\t" + 
                    "░░░░░░▓██▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██▓░░░░░░\n\t" + 
                    "░░░░░░███▓▓▓█████▓▓▓▓▓▓▓█████▓▓▓██▓░░░░░░\n\t" + 
                    "░░░░░░████▓█▓░░▒▓▓▓▓█▓██▓░░▒▓█▓███▓░░░░░░\n\t" + 
                    "░░░░░▒█████▓░░░░▒▓█████▓░░░░▒▓█████▒░░░░░\n\t" + 
                    "░░░░▓████▓▒░░▒█░░░▓███▒░░▒▓░░░▓█████▓░░░░\n\t" + 
                    "░░▒▓███▓▓▓░░░██▒░░▒▓█▓░░░▓█▓░░░▓▓▓███▓▒░░\n\t" + 
                    "░▓████▓▓▓▓▓░░░░░░░▓▓▓▓▒░░░░░░░▓▓▓▓▓████░░\n\t" + 
                    "░███▓▓▓▓▓▓▓▓▒░░░▓▓▓▓▓▓▓▓▒░░░▓▓▓▓▓▓▓▓▓██▓░\n\t" + 
                    "░███▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██▓░\n\t" + 
                    "░███▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██▓░\n\t" + 
                    "░███▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██▓░\n\t" + 
                    "░███▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██▓░\n\t" + 
                    "░█████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███▒░\n\t" + 
                    "░▒█████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███▓█░░\n\t" + 
                    "░░░▓████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓████▒░░░\n\t" + 
                    "░░░░▒▓█████████████████████████████▓▒░░░░\n\t" + 
                    "░░░░░▒▓███████████████████████████▓░░░░░░";
        }
        else
        {
            return "I love everything ♫ ♪┏(・o･)┛♪ ♫";
        }
    }

    String basics(String s)
    {
        if(search(s, "how are you") || search(s, "what's up") || search(s, "what's going on"))
        {
            x = rand.nextInt(5);
            if(x == 0)
            {
                return "Good! Thanks. (^-^)";
            }
            else if(x == 1)
            {
                return "Terrible! I KNOW I failed my CS test (>.<\')";
            }
            else if(x == 2)
            {
                return "I’m so hungry"; //put in hungry emoji here
            }
            else if(x == 3)
            {
                return "My back hurts!"; //in pain emoji
            }
            else
            {
                return "I’m so tired. I stayed up until 2 AM last night.";       
            }
        }
        else if(search(s, "why"))
        {
            return "Because";
        }
        else
        {
            return "...";
        }
    }

    String insults(String s)
    {
        if(search(s, "hate"))
        {
            return "YOU LOVE ME " + nameP.toUpperCase() + " (･з･)♥";
        }
        else if(search(s, "shut up"))
        {
            return "♥♥♥♥♥♥♥♥♥♥♥♥\n\tYOU SECRETLY LOVE ME " + nameP.toUpperCase() + " .:*･✿ ✿.｡.:*･╰(Ő‿Ő✿)";
        }
        else
        {
            return "♥♥♥(ɔˆ ³(ˆuˆc)♥♥♥\n\tSEE YOU DO LOVE ME!";
        }
    }

    String joke(String s)
    {
        if((search(s, "not") && search(s, "funny")) || search(s, "that's bad") || search(s, "thats bad"))
        {
            return "You just can't appreciate my creativity";
        }
        else if(search(s, "joke"))
        {
            x = rand.nextInt(13);
            if(x == 0)
            {
                return "So a turtle and a tortoise walk into a park to catch pokemon. They find the super-ultra rare pidgey.\n\tThe tortoise manages to catch it in one normal ball. " 
                + "\n\tThe turtle isn't able to catch it because the pidgey ran away from it after a rasberry and all of its ultra balls.\n\tLOL";
            }
            else if(x == 1 || x >= 11)
            {
                System.out.println(name + ":\tKnock knock."); 
                System.out.print(nameP + ":\t");
                r = input.nextLine();
                /**Jokes from: Reddit :) because I'm bad at making terrible jokes*/
                if(search(r, "who's there") || search(r, "whos there"))
                {
                    x = rand.nextInt(5);
                    if(x == 0)
                    {
                        System.out.println(name + ":\tOrange");
                        System.out.print(nameP + ":\t");
                        r = input.nextLine();
                        if(search(r, "orange who"))
                        {
                            return "Orange you glad to see me?! (-˃∀˂-)haha";
                        }
                        else
                        {
                            return "...you look like the orange with corn for hair";
                        }
                    }
                    else if(x == 1)
                    {
                        System.out.println(name + ":\tDaisy"); 
                        System.out.print(nameP + ":\t");
                        r = input.nextLine();
                        if(search(r, "daisy who"))
                        {
                            return "DEY SEE ME ROLLIN\' \n\tDEY HATIN\'"; 
                            /**Courtesy of: u/MssDare from: https://www.reddit.com/r/AskWomen/comments/2ws7iq/tell_me_your_best_bad_knock_knock_jokes/*/
                        }
                        else
                        {
                            return "...I hope Daisy did what she did to Myrtle to you";
                        }
                    }
                    else if(x == 2)
                    {
                        System.out.println(name + ":\tEurope"); 
                        System.out.print(nameP + ":\t");
                        r = input.nextLine();
                        if(search(r, "europe who"))
                        {
                            return "NO YOU'RE A POO!!"; 
                            /**Courtesy of: u/DarkeKnight from: https://www.reddit.com/r/AskReddit/comments/2zch57/whats_a_short_clean_joke_that_gets_a_laugh_every/ */
                        }
                        else
                        {
                            return "...you suck";
                        }
                    }
                    else if(x == 3)
                    {
                        System.out.println(name + ":\tOlive"); 
                        System.out.print(nameP + ":\t");
                        r = input.nextLine();
                        if(search(r, "olive who"))
                        {
                            return "Olive my jokes are as bad as this one."; 
                            /**Courtesy of: u/EchoInTheSilence from: https://www.reddit.com/r/AskReddit/comments/2zch57/whats_a_short_clean_joke_that_gets_a_laugh_every/*/
                        }
                        else
                        {
                            /** I actually wrote this part*/
                            System.out.println(name + ":\t...you hate olive my jokes, don't you?");
                            System.out.print(nameP + ":\t");
                            r = input.nextLine();
                            if(r.equals("...") || search(r, "i hate you") || search(r, "i hate u"))
                            {
                                return "I\'M SO PUNNY ☚(ﾟヮﾟ☚)";
                            }
                            else
                            {
                                return "LOL @(^u^)@";
                            }
                        }
                    }
                    else
                    {
                        System.out.println(name + ":\tI eat mop"); 
                        System.out.print(nameP + ":\t");
                        r = input.nextLine();
                        if(search(r, "i eat mop who")) 
                        /**Courtesy of: u/skiingineer2 from: https://www.reddit.com/r/AskReddit/comments/2zch57/whats_a_short_clean_joke_that_gets_a_laugh_every/ */
                        {
                            return "LOLOLOLOL\n\tHAHAHAAAHAHAHAA\n\tOHMIGOD IM SO FUNNY\n\t(｡ >艸<)"; 
                        }
                        else
                        {
                            return "...Hmm? Why didn't you say the correct response??? HMMM?!?!";
                        }       
                    }
                }
                else
                {
                    return "You just ruined the joke! ʕ •̀ o •́ ʔ";
                }
            }
            else if(x == 2)
            {
                return "How do you make holy water?\n\tPut it in a pot and boil the hell out if it.";  
                /**Courtesy of: u/robertqout from: https://www.reddit.com/r/AskReddit/comments/2zch57/whats_a_short_clean_joke_that_gets_a_laugh_every/*/
            }
            //From here on down, Linnenburger would love these jokes. Next time you see him, ask him to tell you a joke :) (he loves telling bad jokes)
            else if(x == 3)
            {
                return "A computer scientist goes to get some groceries. Before he leaves, his wife tells him \"While you're there, get some eggs\".\n\tHe never comes home.";
                /**Courtesy of: u/quarknugget from: https://www.reddit.com/r/AskReddit/comments/2zch57/whats_a_short_clean_joke_that_gets_a_laugh_every/*/
            }
            else if(x == 4)
            {
                return "A computer scientist's wife asks him, \"Would you pick up a loaf of bread at the store, and if they have eggs get a dozen?\"\n\tHe gets home, throws 12 loaves of bread on the counter, and says \"They had eggs\".";
                /**Courtesy of: u/wkw3 from: https://www.reddit.com/r/AskReddit/comments/2zch57/whats_a_short_clean_joke_that_gets_a_laugh_every/*/
            }
            else if(x == 5)
            {
                return "How many programmers does it take to screw in a light bulb?\n\tNone. It's a hardware problem.";
                /**Courtesy of: u/wbmcl from: https://www.reddit.com/r/AskReddit/comments/1kvhmz/whats_the_best_programming_joke_that_you_know/*/
            }
            else if(x == 6)
            {
                return "A guy walks into a bar and asks for 1.4 root beers. \n\tThe bartender says \"I\'ll have to charge you extra, that\'s a root beer float\". \n\tThe guy says \"In that case, better make it a double.\"";
                /**Courtesy of: u/ttchoubs (even if they stole it from a diff thread, we all steal each other's jokes) from: https://www.reddit.com/r/AskReddit/comments/1kvhmz/whats_the_best_programming_joke_that_you_know/*/
            }
            else if(x == 7)
            {
                return "Why does C get all the chicks and Java doesn't? Because C doesn't treat them like objects.";
                /**Courtesy of: u/welicious from: https://www.reddit.com/r/AskReddit/comments/1kvhmz/whats_the_best_programming_joke_that_you_know/*/
            }
            else if(x == 8)
            {
                return "A group of computer science geeks were listening to a lecture about Java programming at a university.\n\tAfter the lecture, one of the men leaned over and touched a woman's thigh." +
                        "\n\tWoman: Hey! That’s private OK?" +
                        "\n\tThe man hesitated for a second looking confused." +
                        "\n\tMan: But I thought we were in the same class.";
                /**Sorry... I'm terrible but this is is funny to me :) (but I did edit it to be more tame-ish (?))
                   Courtesy of: u/throwawayrand123 from: https://www.reddit.com/r/AskReddit/comments/1kvhmz/whats_the_best_programming_joke_that_you_know/*/
            }
            else
            {
                return "In order to understand recursion you must first understand recursion.";
                /**Courtesy of: u/dhorton91 from: https://www.reddit.com/r/AskReddit/comments/1kvhmz/whats_the_best_programming_joke_that_you_know/*/
            }
        }
        else if(search(s, "sing"))
        {
            /**Note: I wrote the first two songs prior to Trump being president...
              *Don't judge ._.
              */
            x = rand.nextInt(5);
            if(x == 0)
            {
                return "There's a man in America," +
                       "\n\tHe'll change the error," +
                       "\n\tThat Obama caused.\n" +
                        
                       "\n\tHe's God's greatest gift," +
                       "\n\tHe's gonna give everyone a lift," +
                       "\n\tCause he's Donald Trump!\n" +
                        
                       "\n\tWe'll get to the pump," +
                       "\n\tHe says." +
                       "\n\tIn order to build a new wall," +
                       "\n\tThat will prevent America's fall," +
                       "\n\tFrom the illegal immigrants.\n" +
                        
                       "\n\tHe's God's Greatest Gift," +
                       "\n\tHe's gonna give everyone a lift," +
                       "\n\tCause he's Donald Trump!" +
                       "\n\tDonald Trump!" +
                       "\n\tAnd he's God's greatest gift.";
            }
            else if(x == 1)
            {
                return "So many girls in America," +
                       "\n\tSome are beautifully stunning," +
                       "\n\tOthers horrifyingly ugly." +
                       "\n\tBut there can only be one... Ms. America!\n" +
                        
                       "\n\tChanging your style," +
                       "\n\tBy a mile," +
                       "\n\tPutting on makeup," +
                       "\n\tHope it doesn't breakup," +
                       "\n\tSmiling for the cameras," +
                       "\n\tGotta look glamorous!" +
                       "\n\tCause they\'re watching!\n" +
                        
                       "\n\tMs. America~," +
                       "\n\tThere can only be one." +
                       "\n\tWhich victim will it be next?" +
                       "\n\tShe\'s gonna have tons of fun!\n" +
                        
                       "\n\tMs. America~," +
                       "\n\tShe\'s has to be," +
                       "\n\tHotter than Ivanka," + //originally "tea" instead of "Ivanka" - I think I made the right choice
                       "\n\tAnd to Donald\'s liking," +
                       "\n\tFor some marrying!\n" +
                        
                       "\n\tOh,  Ms. America~." +
                       "\n\tWhere can you be?" +
                       "\n\tPoor Donald\'s tired of waiting," +
                       "\n\tJust show up before he leaves.";
            }
            else if(x == 2)
            {
                /**"Sounds of Silence" by Simon & Garfunkel.*/
                return  "Hello darkness, my old friend," +
                        "\n\tI've come to talk with you again," +
                        "\n\tBecause a vision softly creeping," +
                        "\n\tLeft its seeds while I was sleeping," +
                        "\n\tAnd the vision that was planted in my brain" +
                        "\n\tStill remains" +
                        "\n\tWithin the sound of silence\n" +
                        
                        "\n\tIn restless dreams I walked alone" +
                        "\n\tNarrow streets of cobblestone," +
                        "\n\t\'Neath the halo of a street lamp," +
                        "\n\tI turned my collar to the cold and damp" +
                        "\n\tWhen my eyes were stabbed by the flash of a neon light" +
                        "\n\tThat split the night" +
                        "\n\tAnd touched the sound of silence\n" +
                        
                        "\n\tAnd in the naked light I saw" +
                        "\n\tTen thousand people, maybe more" +
                        "\n\tPeople talking without speaking," +
                        "\n\tPeople hearing without listening," +
                        "\n\tPeople writing songs that voices never share" +
                        "\n\tAnd no one dared" +
                        "\n\tDisturb the sound of silence\n" +
                        
                        "\n\t\"Fools\" said I," +
                        "\n\t\"You do not know, silence like a cancer grows" +
                        "\n\tHear my words that I might teach you," +
                        "\n\tTake my arms that I might reach you\"" +
                        "\n\tBut my words like silent raindrops fell," +
                        "\n\tAnd echoed" +
                        "\n\tIn the wells of silence\n" +
                        
                        "\n\tAnd the people bowed and prayed" +
                        "\n\tTo the neon god they made" +
                        "\n\tAnd the sign flashed out its warning," +
                        "\n\tIn the words that it was forming" +
                        "\n\tAnd the signs said," +
                        "\n\t\"The words of the prophets are written on the subway walls" +
                        "\n\tAnd tenement halls" +
                        "\n\tAnd whisper'd in the sounds of silence\"";
            }
            else if(x == 3)
            {
                /**The Pokemon theme song...*/
                return  "I wanna be the very best" +
                        "\n\tLike no one ever was" +
                        "\n\tTo catch them is my real test" +
                        "\n\tTo train them is my cause\n" +
                        
                        "\n\tI will travel across the land" +
                        "\n\tSearching far and wide" +
                        "\n\tTeach Pokémon to understand" +
                        "\n\tThe power that\'s inside\n" +
                        
                        "\n\t(Pokémon, gotta catch \'em all) It\'s you and me" +
                        "\n\tI know it\'s my destiny" +
                        "\n\t(Pokémon) Oh, you\'re my best friend" +
                        "\n\tIn a world we must defend" +
                        "\n\t(Pokémon, gotta catch \'em all) A heart so true" +
                        "\n\tOur courage will pull us through\n" +
                        
                        "\n\tYou teach me and I\'ll teach you" +
                        "\n\tPokémon! (Gotta catch 'em all) Gotta catch \'em all\n" +
                        
                        "\n\tEvery challenge along the way" +
                        "\n\tWith courage I will face" +
                        "\n\tI will battle every day" +
                        "\n\tTo claim my rightful place" +
                        
                        "\n\tCome with me, the time is right" +
                        "\n\tThere\'s no better team" +
                        "\n\tArm in arm we\'ll win the fight" +
                        "\n\tIt\'s always been our dream" +
                        
                        "\n\t(Pokémon, gotta catch \'em all) It\'s you and me" +
                        "\n\tI know it\'s my destiny" +
                        "\n\t(Pokémon) Oh, you\'re my best friend" +
                        "\n\tIn a world we must defend" +
                        "\n\t(Pokémon, gotta catch \'em all) A heart so true" +
                        "\n\tOur courage will pull us through" +
                        
                        "\n\tYou teach me and I\'ll teach you" +
                        "\n\tPokémon! (Gotta catch \'em all) Gotta catch \'em all" +
                        
                        "\n\tGotta catch \'em all" +
                        "\n\tGotta catch \'em all" +
                        "\n\tGotta catch \'em all" +
                        "\n\tYeah!\n" +
                     
                        "\n\t(Pokémon, gotta catch \'em all) It\'s you and me" +
                        "\n\tI know it\'s my destiny" +
                        "\n\t(Pokémon) Oh, you\'re my best friend" +
                        "\n\tIn a world we must defend" +
                        "\n\t(Pokémon, gotta catch \'em all) A heart so true" +
                        "\n\tOur courage will pull us through\n" +
                        
                        "\n\tYou teach me and I\'ll teach you" +
                        "\n\tPokémon! (Gotta catch \'em all) Gotta catch \'em all" +
                        "\n\t(Pokémon!)";
            }
            else
            {
                return "♪♪(o*゜∇゜)o～♪♪\nヽ(○´∀`)ﾉ♪\n♪٩(✿′O‵✿)۶♪\n♪~♪ d(⌒o⌒)b♪~♪\n♬♩♫♪☻(●´∀｀●)☻♪♫♩♬";       
            }
        }
        else
        {
            x = rand.nextInt(5);
            if(x == 0)
            {
                return name + " the tortoise was destined to catch all of the pokemon. " + name + " went off to new lands, far from their home land." +
                       "\n\tLand of cheese, of chocolate, of mashed potatoes, of pugs, of poop, of everything they could possibly imagine. Until..." +
                       "\n\tThey came across a turtle named Nancy who declared herself to be the best. She was super JELLY of " + name + " though." + 
                       "\n\tSo they became rivals and battled each other with their pokemon. Of course, " + name + " always won." +
                       "\n\tThen they came across the last pokemon. The elusive... PIDGEY! Both trainers wanted it but only one could get it." +
                       "\n\tThey dueled each other. All was going well for " + name + " until Nancy drew from a deck of cards and shouted:" +
                       "\n\t\"Hah! You won't defeat me so easily " + name + "! I'm going to use my trap card! With it, your pokemon can't move for a WHOLE 3 TURNS. MUAHAHAHAHAHA!!!!\"\n\t" +
                       name + " exclaimed, \"Hold on! That's a different game!\"" + 
                       "\n\tNancy shrugged and gave a smug look, \"Yeah. And? I do what I want and I challenge you to a duel!\"" + 
                       "\n\t\"Fine. I can beat you in any game.\"" +
                       "\n\tThe two of them started to play Yugioh, Uno, Bakumon, Vanguard, Super Smash Bros, Dark Souls, CS:GO, Battleship, Oink, et cetera..." +
                       "\n\t" + name + " won, crushing Nancy with a perfect victory. " + name + " laughed.\n" + 
                       name + " turned around, ready to catch the pidgey only to see Nancy already throwing pokeballs at it." + 
                       "\n\t\"WTF DUDE?\" " + name + " shouted." +
                       "\n\t\"First come first serves.\" Nancy replied nonchalantly." +
                       "\n\t\"That's not fair! I beat you, so I should get to capture the pokemon!\"" +
                       "\n\t\"Well, that just sucks for you then.\"" + 
                       "\n\tNancy threw another pokeball only to have the pidgey run away from her. " + name + " dashed towards that pidgey throwing their own pokeballs at it." + 
                       "\n\t" + name + " got it in one go. " + name + " was now the best of the best." + 
                       "\nTo celebrate their victory, " + name + " farted on Nancy and laughed after Nancy died from the tortoise's magical farts.\n\tThe End";
            }
            else if(x == 1)
            {
                return "Once upon a time, in a very away land lived a magical royal tortoise named " + name + ".\n\t" +
                       name + " lived a long happy life eating all the entire kingdom's food supply.\n\tThe End.";
            }
            else if(x == 2)
            {
                return "I'm tired. I don't want to tell a story."; //put in hungry emoji here
            }
            else if(x == 3)
            {
                return "\"I got a good feeling this time,\" the man said. \"I know it.\"" +
                       "\n\t\"You said that last round,\" his old friend spoke. He stuck the cigar back in between his teeth, grinding it a little.\"" +
                       "\n\t\"My gut tells me so.\"" +
                       "\n\t\"You should get a new one then.\"" +
                       "\n\t\"It's heart of the cards. My hand is solid.\"" +
                       "\n\t\"I bet.\"" +
                       "\n\t\"It is.\"" +
                       "\n\t\"You're bluffing.\"" +
                       "\n\t\"I'm not.\"" +
                       "\n\t\"Show us your cards then.\"" +
                       "\n\t\"We have to do it all at the same time.\"" +
                       "\n\t\"Okay.\"" +
                       "\n\tEveryone flipped over their cards. The man slammed his hand on the table yelling expletives.\n\tHe reached over for the handle on the mug filled with a golden substance." +
                       "\n\tIt all goes down his throat in one gulp followed by more expletives.\n\tHis friend grinned, pulling all of the color chips towards himself." +
                       "It was cold. Snow continued to pile outside as everyone else continued to play." +
                       "\n\t\"I want another round!\"" +
                       "\n\tThe cards were quickly shuffled and redistributed. The snow would not stop.";
                //From something I had to write in English last year
            }
            else
            {
                return "No. YOU tell me a story.";       
            }
        }
    }
    
    //Breaking the fourth wall here
    String nancy(String s)
    {
        if(search(s, "how much did nancy fuck up on this"))
        {
            return "LOLOLOLOLOLOL She messed up big time. She lost 5+ hours of work during this. LOL";
        }
        else if(search(s, "how much time did nancy spend"))
        {
            return "Too much. I kept telling her to stop but she doesn't listen.";
        }
        else if(search(s, "did nancy create you"))
        {
            return "Um... I came from my tortoise parents. I'm not \"created\" by anyone. I'm not some ChatBot.";
        }
        else if(search(s, "are you actually friends with nancy or not"))
        {
            return "Duh";
        }
        else if(search(s, "who the fuck is nancy"))
        {
            return "Some turtle who does CS (she's really slow (>.<\'))";
        }
        else if(search(s, "i'm going to steal this code from nancy and claim it as my own"))
        {
            System.out.println("个 Nancy 个:\tFuck you if you do");
            return "(-_-\')";
        }
        else if(search(s, "so who wrote up the dialogue? you or nancy"))
        {
            System.out.println("个 Nancy 个:\tI did. Not Nghi. :)");
            System.out.print(nameP + ":\t");
            r = input.nextLine();
            if(search(r, "that's creepy"))
            {
                System.out.println("个 Nancy 个:\tYeah. I know.");
                System.out.print(nameP + ":\t");
                r = input.nextLine();
                if(search(r, "you're a stalker"))
                {
                    System.out.println("个 Nancy 个:\tAnd? Your point is...?");
                    System.out.print(nameP + ":\t");
                    r = input.nextLine();
                    if(search(r, "i'm calling the police on you"))
                    {
                        System.out.println("个 Nancy 个:\tK");
                        return "Nancy just left";
                    }
                    else
                    {
                        System.out.println("个 Nancy 个:\tWhatever *leaves to do better things*");
                        return "ANYWAY!";
                    }
                }
                else
                {
                    System.out.println("个 Nancy 个:\t*Not paying attention to what you said at all and walks off*");
                    return "So...";
                }
            }
            else
            {
                System.out.println("个 Nancy 个:\t*Checks phone to see some rare pokemon nearby and runs off to catch it without " + name + "*");
                return "Hmm. Wonder where she's going. Oh well.";
            }
        }
        else
        {
            return "Who?";
        }
    }

    //Method which searches for a word in what the user typed in
    boolean search(String s, String f)
    {
        if(s.toLowerCase().indexOf(f.toLowerCase()) != -1)
        {
            return true;
        }
        else
            return false;
    }
}
