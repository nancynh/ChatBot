/**
   Written & Coded By: Nancy Hong
   Date: Feb 3, 2017
   For: Girl's Who Code Club (at Central)
   */

import java.util.Random;    //Same thing as the java.util.Scanner in the ChatbotRunner class except this time, the program is getting info from a book called "Random"

public class Chatbot
{
    private String name; //name of the chatbot
    private Random rand = new Random();  //random number thing
    private int x; //        x = rand.nextInt(3) + 0; is some sample code. 2 would be the max. "+ 0" would mean 0 is the mean but unnecssary to write
    
    //Constructor. Basically assigns the passed in variables (n which is a String type) into the instance data (in this case, name) 
    public Chatbot(String n)
    {
        name = n;
    }
    
    //Getter method. Methods are the yellow blocks you see. 
    //Because name is private, it cannot be accesed by other classes (with some exceptions). So we need to write a getter method to allow other classes to "get" the name
    String getName() { return name; }

    //Below are all of the methods used to help make the chatbot more... lively? 
    String greeting(String s)
    {     
        return "Hi! ( ´ ▽ ` )ﾉ";
    }

    String respond(String s)
    {
        if(search(s, "sigh"))
        {
            return "What's wrong?";
        }
        else
        {
            x = rand.nextInt(6);
            if(x == 0)
            {
                return "Cool story bro";
            }
            else if(x == 1)
            {
                return "(∪｡∪)｡｡｡zzz\n\tWut... did you say something?";
            }
            else if(x == 2)
            {
                return "That's nice";
            }
            else if(x == 3)
            {
                return "Lol";
            }
            else if(x == 4)
            {
                return "XD";
            }
            else
            {
                return "I'm a tortoise and I have magical powers.";
            }
        }
    }

    //Method which searches for a word in what the user typed in
    boolean search(String s, String f)
    {
        if(s.toLowerCase().indexOf(f.toLowerCase()) != -1)
        {
            return true;
        }
        else
            return false;
    }
}
